package com.projeto.models.service;

import com.projeto.models.model.Role;

public interface RoleService extends GenericService<Role,Role, Long> {

}
