package com.projeto.models.service.exception;

public class InvalidJwtAuthenticationException extends NegocioException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1071630810797652516L;

	public InvalidJwtAuthenticationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
