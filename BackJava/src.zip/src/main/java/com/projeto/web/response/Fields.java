package com.projeto.web.response;

public class Fields {

    private String nome;
    private String mensagemCliente;
	
    public String getNome() {
		return nome;
	}
	
    public void setNome(String nome) {
		this.nome = nome;
	}
	
    public String getMensagemCliente() {
		return mensagemCliente;
	}
	
    public void setMensagemCliente(String mensagemCliente) {
		this.mensagemCliente = mensagemCliente;
	}

}
